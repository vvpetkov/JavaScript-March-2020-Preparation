module.exports = {
    printWidth: 120,
    semi: false,
    singleQuote: true,
    tabWidth: 4,
}
