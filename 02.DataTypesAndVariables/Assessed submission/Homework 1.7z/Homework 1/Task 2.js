let input = ['Telerik Academy', '31 Al. Malinov, Sofia', '	+359 888 55 55 555','(no fax)', 'http://telerikacademy.com/', 'Martin', 'Veshev', '25', '+359 2 981 981'];
let print = this.print || console.log;
let gets = this.gets || ((arr, index)=> () => arr[index++]) (input,0);

let companyName = gets();
let companyAdress = gets();
let phoneNo = gets();
let faxNo = gets();
let site = gets();
let firstName = gets();
let lastName = gets();
let age = gets();
let managerPhone = gets();

print(companyName,"\n", "Adress :", companyAdress, "\n", "Tel.", phoneNo, "\n", "Fax: ", faxNo, "\n", "Web Site: ", site, "\n", "Manager: ", firstName, lastName)