let input = ['2', '5', '-3'];
let print = this.print || console.log;
let gets = this.gets || ((arr, index)=> () => arr[index++]) (input,0);

let 
a=+gets();
b=+gets();
c=+gets();

let partial_root = Math.sqrt(b*b - 4 * a * c);
let denom = 2*a;
let root1 = (-b + partial_root) / denom;
let root2 = (-b - partial_root) / denom;

print ("x1="+root1);
print ("x2="+root2);