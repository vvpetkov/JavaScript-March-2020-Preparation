let input = ['5'];
let print = this.print || console.log;
let gets = this.gets || ((arr, index)=> () => arr[index++]) (input,0);

let r =+ gets();
let d = r*2;
let pi = Math.PI;
let perimeter = pi * d;
let area = pi * r * r;
print ("The perimeter is :", perimeter = perimeter.toFixed(2));
print ("The area is :", area = area.toFixed(2));