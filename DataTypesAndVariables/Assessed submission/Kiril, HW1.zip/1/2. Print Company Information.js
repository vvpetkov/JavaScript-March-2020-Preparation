let input = [];
let print = this.print || console.log;
let gets = this.gets || ((arr, index) => () => arr[index++])(input, 0);

let companyName = gets();
let companyAddress = gets();
let phoneNumber = gets();
let faxNumber = gets();
let webSite = gets();
let managerFirstName = gets();
let managerLastName = gets();
let managerAge = gets();
let managerPhone = gets();

print(companyName);
print(`Address: ${companyAddress}`);
print(`Tel. ${phoneNumber}`);
print("Fax: (no fax)");
print(`Web site: ${webSite}`);
print(`Manager: ${managerFirstName} ${managerLastName} (age: ${managerAge}, tel. ${managerPhone})`)